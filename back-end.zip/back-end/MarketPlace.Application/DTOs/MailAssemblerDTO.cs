﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MarketPlace.Application.DTOs
{
    public class MailAssemblerDTO
    {
        public string? templateName { get; set; }
        public string[]? parmList { get; set; }
    }
}
